-> Para carregar corretamente:
1. Se quiser carregar mais de um obj, carregue todos de uma vez;
2. index 0 = obj2_vase_A, index 1 = obj1_bowling  
3. obj1_bowling(escala = 0.3) e obj2_vase_A(escala = 3)
4. translação obj2_vase_A(0,0.35,0,-0.2), translação obj1_bowling(0,0,0) 
